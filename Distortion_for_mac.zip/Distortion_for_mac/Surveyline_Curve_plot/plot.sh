#!/bin/bash

# 从文本文件中读取文件名到数组中
mapfile -t TErho_files < catalogue/RhoTE_files.txt
mapfile -t TMrho_files < catalogue/RhoTM_files.txt
mapfile -t TEpha_files < catalogue/PhaTE_files.txt
mapfile -t TMpha_files < catalogue/PhaTM_files.txt
mapfile -t oriTErho_files < catalogue/oriRhoTE_files.txt
mapfile -t oriTMrho_files < catalogue/oriRhoTM_files.txt
mapfile -t oriTEpha_files < catalogue/oriPhaTE_files.txt
mapfile -t oriTMpha_files < catalogue/oriPhaTM_files.txt
mapfile -t strike_files < catalogue/strike_files.txt
mapfile -t skew_files < catalogue/skew_files.txt
mapfile -t site_files < file/site.dat

for ((i=0; i<${#TErho_files[@]}; i++)); do
  TErho_file=${TErho_files[$i]}
  TMrho_file=${TMrho_files[$i]}
  TEpha_file=${TEpha_files[$i]}
  TMpha_file=${TMpha_files[$i]}
 oriTErho_file=${oriTErho_files[$i]}
  oriTMrho_file=${oriTMrho_files[$i]}
  oriTEpha_file=${oriTEpha_files[$i]}
  oriTMpha_file=${oriTMpha_files[$i]}
  strike_file=${strike_files[$i]}
  skew_file=${skew_files[$i]}
site_file=${site_files[$i]}


  # 生成每一个单独的PNG文件
  gmt begin result/map_$((i + 1)) png

    gmt subplot begin 3x2 -Fs12c/4c -M1.5c -T"SITE"$((i + 1))"  "$site_file"km"
    
      # 第一个子图
      gmt subplot set 0
      gmt basemap -R-4/3/-1/5 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"Original Apparent Reistivity" 
      gmt plot $oriTErho_file -Sc0.07 -W0.13p,blue,solid -l"Rhoxy" -Ey+w1.5p+pblue,solid
      gmt plot $oriTMrho_file -Sc0.07 -W0.13p,red,solid -l"Rhoyx" -Ey+w1.5p+pred,solid 
      gmt legend -DjTL+o0.1c/0.1c -F+p1p
      
      # 第二个子图
      gmt subplot set 1
      gmt basemap -R-4/3/-1/5 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"After Distortion Apparent Reistivity" 
      gmt plot $TErho_file -Sc0.07 -W0.13p,blue,solid -l"Rhoxy" -Ey+w1.5p+pblue,solid
      gmt plot $TMrho_file -Sc0.07 -W0.13p,red,solid -l"Rhoyx" -Ey+w1.5p+pred,solid 
      gmt legend -DjTL+o0.1c/0.1c -F+p1p

      # 第三个子图
      gmt subplot set 2
      gmt basemap -R-4/3/0/90 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"Original Phase" 
      gmt plot $oriTEpha_file -Sc0.07 -W0.13p,blue,solid -l"Phaxy" -Ey+w1.5p+pblue,solid
      gmt plot $oriTMpha_file -Sc0.07 -W0.13p,red,solid -l"Phayx" -Ey+w1.5p+pred,solid 
      gmt legend -DjTL+o0.1c/0.1c -F+p1p
      
      # 第四个子图
      gmt subplot set 3
      gmt basemap -R-4/3/0/90 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"After Distortion Phase"  
      gmt plot $TEpha_file -Sc0.07 -W0.13p,blue,solid -l"Phaxy" -Ey+w1.5p+pblue,solid
      gmt plot $TMpha_file -Sc0.07 -W0.13p,red,solid -l"Phayx" -Ey+w1.5p+pred,solid 
      gmt legend -DjTL+o0.1c/0.1c -F+p1p

      # 第五个子图
      gmt subplot set 4
      gmt basemap -R-4/3/-1.5/1.5 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"Skew" 
      gmt plot $skew_file -Sc0.1 -W0.5p,black,solid
      
      # 第六个子图
      gmt subplot set 5
      gmt basemap -R-4/3/-90/90 -JX-12c/4c -Bxaf+l"Frequency(Hz)" -Byaf -BWSen+t"Azimuth strike"  
      gmt plot $strike_file -Sc0.1 -W0.5p,black,solid

    gmt subplot end

  gmt end show

done