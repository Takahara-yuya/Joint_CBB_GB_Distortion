NAME=LINE:NS11
PHACPT=cpt/pha.cpt
RHOCPT=cpt/rho.cpt
file=file/site.dat
root=file

RMAX=$(tail -n 1 "$file")

gmt begin result/map_0 png

  gmt subplot begin 3x2 -Fs12c/4c -M2.5c -T$NAME

  gmt subplot set 0
  gmt basemap -R0/$RMAX/-3.5/2.5 -JX12c/4c -Bxaf+l"X [km]" -Byaf+l"frequency]Hz]" -BSWen+t"RhoTE" 
  gmt surface $root/2D_distortion_RhoTE.dat -G$root/2D_distortion_RhoTE.nc -I10/0.2 -R0/$RMAX/-3.5/2.5 -V
  #gmt makecpt -T-1/5/0.02 -Cjet -H >$RHOCPT
  gmt grdimage $root/2D_distortion_RhoTE.nc -JX12c/4c -C$RHOCPT
  gmt colorbar -C$RHOCPT  -B+l"Log(Ohm m)"

  gmt subplot set 1
   gmt basemap -R0/$RMAX/-3.5/2.5 -JX12c/4c -Bxaf+l"X [km]" -Byaf+l"frequency]Hz]" -BSWen+t"RhoTM" 
  gmt surface $root/2D_distortion_RhoTM.dat -G$root/2D_distortion_RhoTM.nc -I10/0.2 -R0/$RMAX/-3.5/2.5 -V
  gmt grdimage $root/2D_distortion_RhoTM.nc -JX12c/4c -C$RHOCPT
  gmt colorbar -C$RHOCPT  -B+l"Log(Ohm m)"


  gmt subplot set 2
   gmt basemap -R0/$RMAX/-3.5/2.5 -JX12c/4c -Bxaf+l"X [km]" -Byaf+l"frequency]Hz]" -BSWen+t"PhaTE" 
  gmt surface $root/2D_distortion_PhaTE.dat -G$root/2D_distortion_PhaTE.nc -I10/0.1 -R0/$RMAX/-3.5/2.5 -V
  #gmt makecpt -T0/93/0.5 -Cjet -H >$PHACPT
  gmt grdimage $root/2D_distortion_PhaTE.nc -JX12c/4c -C$PHACPT
  gmt colorbar -C$PHACPT  -B+l"Degree"

 gmt subplot set 3
   gmt basemap -R0/$RMAX/-3.5/2.5 -JX12c/4c -Bxaf+l"X [km]" -Byaf+l"frequency]Hz]" -BSWen+t"PhaTM" 
  gmt surface $root/2D_distortion_PhaTM.dat -G$root/2D_distortion_PhaTM.nc -I10/0.1 -R0/$RMAX/-3.5/2.5 -V
  gmt grdimage $root/2D_distortion_PhaTM.nc -JX12c/4c -C$PHACPT
  gmt colorbar -C$PHACPT  -B+l"Degree"

 gmt subplot set 4
   gmt basemap -R-90/90/0/200 -JX12c/4c -Bxaf+l"X [km]"  -Bxaf+l"Strike" -Byaf+l"Counts" -BWSen
  gmt histogram $root/Static_100_1s_strike.dat  -W1p -Gblue -T5 -i2

 gmt subplot set 5
  gmt basemap -R-5/$RMAX/-0.5/6 -JX12c/4c -Bxaf+l"X [km]" -Byaf+l"frequency]Hz]" -BSWen+t"RMS Misfit" 
  gmt plot $root/misfit.dat -St0.15 -W0.03p -Gred
  gmt plot $root/misfit_init.dat -Sd0.12 -W0.03p -Gblack

    
gmt subplot end

  gmt end show