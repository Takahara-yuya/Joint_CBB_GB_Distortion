#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;
int main()
{
	double tmp;
	string tmp2;
	double* RhoTE, * RhoTM, * PhaTE, * PhaTM;
	double* errRhoTE, * errRhoTM, * errPhaTE, * errPhaTM;
	double* site, * freq;
	double* beta, * strike;
	int nfre, nsite;
	string filename = "inputfile/2D_distortion.dat";
	ifstream fin(filename);
	if (!fin)
	{
		cerr << "2D_distortion.dat open failed!" << endl;
		exit(1);
	}
	string filename1 = "inputfile/Original_data.dat";
	ifstream fin1(filename1);
	if (!fin1)
	{
		cerr << "Original_data.dat open failed!" << endl;
		exit(1);
	}
	string filename2 = "inputfile/Phase_Tensor_Analysis.dat";
	ifstream fin2(filename2);
	if (!fin2)
	{
		cerr << "Phase_Tensor_Analysis.dat open failed!" << endl;
		exit(1);
	}
	fin >> nsite >> nfre;
	fin1 >> nsite >> nfre;
	string data;
	getline(fin2, data);
	ofstream fout3("catalogue/PhaTE_files.txt");
	ofstream fout4("catalogue/PhaTM_files.txt");
	ofstream fout1("catalogue/RhoTE_files.txt");
	ofstream fout2("catalogue/RhoTM_files.txt");
	ofstream fout7("catalogue/oriPhaTE_files.txt");
	ofstream fout8("catalogue/oriPhaTM_files.txt");
	ofstream fout5("catalogue/oriRhoTE_files.txt");
	ofstream fout6("catalogue/oriRhoTM_files.txt");
	ofstream fout9("catalogue/skew_files.txt");
	ofstream fout10("catalogue/strike_files.txt");
	freq = new double[nfre];
	RhoTE = new double[nfre]; RhoTM = new double[nfre]; PhaTE = new double[nfre]; PhaTM = new double[nfre];
	errRhoTE = new double[nfre]; errRhoTM = new double[nfre]; errPhaTE = new double[nfre]; errPhaTM = new double[nfre];
	site = new double[nsite];
	beta = new double[nfre]; strike = new double[nfre];
	///

	ofstream** foutt;
	foutt = new ofstream * [nsite];
	for (int i = 0; i < nsite; i++)
	{
		foutt[i] = new ofstream[10];
	}
	for (int i = 0; i < nsite; i++)
	{
		string file1 = "file/RhoTE" + to_string(i + 1) + ".dat";
		string file2 = "file/RhoTM" + to_string(i + 1) + ".dat";
		string file3 = "file/PhaTE" + to_string(i + 1) + ".dat";
		string file4 = "file/PhaTM" + to_string(i + 1) + ".dat";
		string file5 = "file/oriRhoTE" + to_string(i + 1) + ".dat";
		string file6 = "file/oriRhoTM" + to_string(i + 1) + ".dat";
		string file7 = "file/oriPhaTE" + to_string(i + 1) + ".dat";
		string file8 = "file/oriPhaTM" + to_string(i + 1) + ".dat";
		string file9 = "file/skew" + to_string(i + 1) + ".dat";
		string file10 = "file/strike" + to_string(i + 1) + ".dat";
		fout1 << file1 << endl;
		fout2 << file2 << endl;
		fout3 << file3 << endl;
		fout4 << file4 << endl;
		fout5 << file5 << endl;
		fout6 << file6 << endl;
		fout7 << file7 << endl;
		fout8 << file8 << endl;
		fout9 << file9 << endl;
		fout10 << file10 << endl;
		foutt[i][0].open(file1);
		foutt[i][1].open(file2);
		foutt[i][2].open(file3);
		foutt[i][3].open(file4);
		foutt[i][4].open(file5);
		foutt[i][5].open(file6);
		foutt[i][6].open(file7);
		foutt[i][7].open(file8);
		foutt[i][8].open(file9);
		foutt[i][9].open(file10);
	}
	for (int isite = 0; isite < nsite; isite++)
	{
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin >> site[isite] >> freq[ifre] >> RhoTE[ifre] >> PhaTE[ifre] >> RhoTM[ifre] >> PhaTM[ifre]
				>> errRhoTE[ifre] >> errRhoTM[ifre] >> errPhaTE[ifre] >> errPhaTM[ifre];
			errRhoTE[ifre] = abs( errRhoTE[ifre] / 0.434 * RhoTE[ifre]);
			errRhoTM[ifre] = abs( errRhoTM[ifre] / 0.434 * RhoTM[ifre]);
			errPhaTE[ifre] = abs( errPhaTE[ifre] / 28.5 * PhaTE[ifre]);
			errPhaTM[ifre] = abs( errPhaTM[ifre] / 28.5 * PhaTM[ifre]);
		}
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			foutt[isite][0] << freq[ifre] << " " << RhoTE[ifre] << " " << errRhoTE[ifre] << endl;
			foutt[isite][1] << freq[ifre] << " " << RhoTM[ifre] << " " << errRhoTM[ifre] << endl;
			foutt[isite][2] << freq[ifre] << " " << PhaTE[ifre] << " " << errPhaTE[ifre] << endl;
			foutt[isite][3] << freq[ifre] << " " << PhaTM[ifre] << " " << errPhaTM[ifre] << endl;
		}
	}
	////
	for (int isite = 0; isite < nsite; isite++)
	{
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin1 >> site[isite] >> freq[ifre] >> RhoTE[ifre] >> PhaTE[ifre] >> RhoTM[ifre] >> PhaTM[ifre]
				>> errRhoTE[ifre] >> errRhoTM[ifre] >> errPhaTE[ifre] >> errPhaTM[ifre];
			errRhoTE[ifre] = abs(errRhoTE[ifre] / 0.434 * RhoTE[ifre]);
			errRhoTM[ifre] = abs(errRhoTM[ifre] / 0.434 * RhoTM[ifre]);
			errPhaTE[ifre] = abs(errPhaTE[ifre] / 28.5 * PhaTE[ifre]);
			errPhaTM[ifre] = abs( errPhaTM[ifre] / 28.5 * PhaTM[ifre]);
		}
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			foutt[isite][4] << freq[ifre] << " " << RhoTE[ifre] << " " << errRhoTE[ifre] << endl;
			foutt[isite][5] << freq[ifre] << " " << RhoTM[ifre] << " " << errRhoTM[ifre] << endl;
			foutt[isite][6] << freq[ifre] << " " << PhaTE[ifre] << " " << errPhaTE[ifre] << endl;
			foutt[isite][7] << freq[ifre] << " " << PhaTM[ifre] << " " << errPhaTM[ifre] << endl;
		}
	}
	for (int isite = 0; isite < nsite; isite++)
	{
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin2 >> site[isite] >> freq[ifre] >> beta[ifre] >> strike[ifre] >> tmp >> tmp2 >> tmp2;
		}
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			foutt[isite][8] << freq[ifre] << " " << beta[ifre] << endl;
			foutt[isite][9] << freq[ifre] << " " << strike[ifre] << endl;
		}
	}
}