#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;
int main()
{
	double tmp, tmp1, tmp3;
	string tmp2;
	double* RhoTE, * RhoTM, * PhaTE, * PhaTM;
	double* site, * freq;
	double* misfit, * misfit_init, * strike;
	int nfre, nsite;
	string filename = "inputfile/2D_distortion.dat";
	ifstream fin(filename);
	if (!fin)
	{
		cerr << "2D_distortion.dat open failed!" << endl;
		exit(1);
	}
	string filename1 = "inputfile/debug.dat";
	ifstream fin1(filename1);
	if (!fin1)
	{
		cerr << "debug.dat open failed!" << endl;
		exit(1);
	}
	string filename2 = "inputfile/simulatedAnnealing.dat";
	ifstream fin2(filename2);
	if (!fin2)
	{
		cerr << "simulatedAnnealing.dat open failed!" << endl;
		exit(1);
	}
	fin >> nsite >> nfre;
	string data;
	getline(fin1, data);
	getline(fin2, data);
	ofstream fout1("file/site.dat");
	ofstream fout2("file/2D_distortion_RhoTE.dat");
	ofstream fout3("file/2D_distortion_RhoTM.dat");
	ofstream fout4("file/2D_distortion_PhaTE.dat");
	ofstream fout5("file/2D_distortion_PhaTM.dat");
	ofstream fout6("file/avestrike.dat");
	ofstream fout7("file/misfit.dat");
	ofstream fout8("file/misfit_init.dat");

	freq = new double[nfre];
	RhoTE = new double[nfre]; RhoTM = new double[nfre]; PhaTE = new double[nfre]; PhaTM = new double[nfre];
	site = new double[nsite];
	misfit = new double[nsite]; strike = new double[nsite];
	misfit_init = new double[nsite];
	///

	for (int isite = 0; isite < nsite; isite++)
	{
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin >> site[isite] >> freq[ifre] >> RhoTE[ifre] >> PhaTE[ifre] >> RhoTM[ifre] >> PhaTM[ifre]
				>> tmp >> tmp >> tmp >> tmp;
		}
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fout2 << site[isite] << " " << freq[ifre] << " " << RhoTE[ifre] << endl;
			fout3 << site[isite] << " " << freq[ifre] << " " << RhoTM[ifre] << endl;
			fout4 << site[isite] << " " << freq[ifre] << " " << PhaTE[ifre] << endl;
			fout5 << site[isite] << " " << freq[ifre] << " " << PhaTM[ifre] << endl;
		}
		fout1 << site[isite] << endl;
	}
	////
	for (int isite = 0; isite < nsite; isite++)
	{
		fin1 >> tmp >> tmp >> tmp >> tmp >> tmp >> tmp >> strike[isite];
		fout6 << site[isite] << " " << strike[isite] << endl;
	}

	for (int isite = 0; isite < nsite; isite++)
	{
		misfit[isite] = 0;
		misfit_init[isite] = 0;
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin2 >> tmp >> tmp >> tmp >> tmp >> tmp >> tmp1 >> tmp3;
			misfit[isite] += tmp3;
			misfit_init[isite] += tmp1;
		}
		fout7 << site[isite] << " " << misfit[isite] / 80. << endl;
		fout8 << site[isite] << " " << misfit_init[isite] / 80. << endl;
	}
}