/*
***********************************************************************

Joint_GB_CBB_Distortion.cpp	(Main program)

***********************************************************************

May 21, 2024
Copyright 2024

Zuwei Huang
hzw1498218560@tongji.edu.cn
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

Reference:
[1]Bibby, H.M., Caldwell, T.G. and Brown, C. (2005), Determinable and non-determinable parameters of galvanic distortion in magnetotellurics.
	 Geophysical Journal International, 163: 915-930. https://doi.org/10.1111/j.1365-246X.2005.02779.x
[2]Caldwell, T.G., Bibby, H.M. and Brown, C. (2004), The magnetotelluric phase tensor.
	 Geophysical Journal International, 158: 457-469. https://doi.org/10.1111/j.1365-246X.2004.02281.x

version 2.1.0

* ***********************************************************************
*/
#include "../include/CommonHeaders.h"
#include "../include/Yu_simulatedAnnealing.h"
int main()
{
	// Copyright and license notice:
	std::cout << std::endl;
	std::cout << "***************************************************************************" << std::endl << std::endl;
	std::cout << "                   Joint_GB_CBB_Distortion                                 " << std::endl << std::endl;
	std::cout << "                Copyright 2024, Zuwei Huang              " << std::endl << std::endl;

	std::cout << "  Joint_GB_CBB_Distortion is free software: you can redistribute it and/or modify it under the " << std::endl <<
		"  terms of the GNU Lesser General Public License as published by the Free " << std::endl <<
		"  Software Foundation, version 3 of the License. " << std::endl << std::endl;

	std::cout << "  Joint_GB_CBB_Distortion is distributed in the hope that it will be useful, but WITHOUT ANY " << std::endl <<
		"  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS " << std::endl <<
		"  FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for " << std::endl <<
		"  more details. " << std::endl << std::endl;
	std::cout << "***************************************************************************" << std::endl << std::endl;
	//

	string a1;
	int type, nfre, nsite, dist;
	int SA, smooth_strike;
	double* freq;
	//plane
	int nfrep;
	double dd_x, dd_y;
	//line
	double* site;
	//
	double _1D_limit = 0.1;
	double _2D_limit = 1.5;
	//
	double smooth = 0.25;
	double coeff = 5.;
	double ec = 1;
	//double ec = 796.1;
	bool rot = true;
	//
	double* VarZ11, * VarZ12, * VarZ21, * VarZ22;//phase tensor
	double* X11, * X22, * X12, * X21, * Y11, * Y12, * Y21, * Y22;//impendence tensor
	double* P11, * P12, * P22, * P21;//phase tensor
	double* PMAX, * PMIN, * alpha, * beta, * lmbda, * strike, * strike_42, * alp_ave;//ellipse parameter
	vector<int> oneD_frs, oneD_fre, twoD_frs, twoD_fre;
	string filename;
	ifstream f1("startup");
	if (!f1)
	{
		cerr << "No statup file " << endl;
		exit(1);
	}
	f1 >> a1 >> filename;
	cerr << "Input Filename: " << filename << endl;
	f1 >> a1 >> a1 >> type;
	f1 >> a1 >> dist;
	f1 >> a1 >> a1 >> smooth;
	f1 >> a1 >> a1 >> _1D_limit;
	f1 >> a1 >> a1 >> _2D_limit;
	f1 >> a1 >> a1 >> smooth_strike;
	f1 >> a1 >> a1 >> SA;
	f1.close();
	ifstream fin(filename);
	if (!fin)
	{
		cerr << "No inputfile named : " << filename << endl;
		exit(1);
	}
	ifstream fin1(filename);
	ofstream fout("result/Phase_Tensor_Analysis.dat");
	ofstream fout2("result/1D_distortion.dat");
	ofstream fout3("result/2D_distortion.dat");
	ofstream fout4("result/Original_data.dat");
	ofstream fo("result/simulatedAnnealing.dat");
	ofstream fo2("result/debug.dat");
	///
	fin >> nsite >> nfre;
	fin1 >> nsite >> nfre;
	freq = new double[nfre];
	X11 = new double[nfre]; X22 = new double[nfre]; X12 = new double[nfre]; X21 = new double[nfre];
	Y11 = new double[nfre]; Y22 = new double[nfre]; Y12 = new double[nfre]; Y21 = new double[nfre];
	P11 = new double[nfre]; P22 = new double[nfre]; P12 = new double[nfre]; P21 = new double[nfre];
	VarZ11 = new double[nfre]; VarZ12 = new double[nfre]; VarZ21 = new double[nfre]; VarZ22 = new double[nfre];
	PMAX = new double[nfre]; PMIN = new double[nfre]; alpha = new double[nfre]; beta = new double[nfre]; lmbda = new double[nfre];
	strike = new double[nfre]; strike_42 = new double[nfre];
	site = new double[nsite]; alp_ave = new double[nsite];
	vector< vector<double> > Rhoxy_ori, Rhoyx_ori, Phaxy_ori, Phayx_ori;
	vector< vector<double> > Rhoxy, Rhoyx, Phaxy, Phayx;
	vector< vector<double> > Rhoxy_1D, Rhoyx_1D, Phaxy_1D, Phayx_1D;
	vector< vector<double> > err_Rhoxy_ori, err_Rhoyx_ori, err_Phaxy_ori, err_Phayx_ori;
	vector< vector<double> > err_Rhoxy, err_Rhoyx, err_Phaxy, err_Phayx;
	Rhoxy_ori.resize(nsite); Rhoyx_ori.resize(nsite); Phaxy_ori.resize(nsite); Phayx_ori.resize(nsite);
	Rhoxy.resize(nsite); Rhoyx.resize(nsite); Phaxy.resize(nsite); Phayx.resize(nsite);
	Rhoxy_1D.resize(nsite); Rhoyx_1D.resize(nsite); Phaxy_1D.resize(nsite); Phayx_1D.resize(nsite);
	err_Rhoxy_ori.resize(nsite); err_Rhoyx_ori.resize(nsite); err_Phaxy_ori.resize(nsite); err_Phayx_ori.resize(nsite);
	err_Rhoxy.resize(nsite); err_Rhoyx.resize(nsite); err_Phaxy.resize(nsite); err_Phayx.resize(nsite);
	oneD_frs.resize(nsite); oneD_fre.resize(nsite); twoD_frs.resize(nsite); twoD_fre.resize(nsite);
	for (int isite = 0; isite < nsite; isite++)
	{
		Rhoxy[isite].resize(nfre); Rhoyx[isite].resize(nfre); Phaxy[isite].resize(nfre); Phayx[isite].resize(nfre);
		Rhoxy_1D[isite].resize(nfre); Rhoyx_1D[isite].resize(nfre); Phaxy_1D[isite].resize(nfre); Phayx_1D[isite].resize(nfre);
		Rhoxy_ori[isite].resize(nfre); Rhoyx_ori[isite].resize(nfre); Phaxy_ori[isite].resize(nfre); Phayx_ori[isite].resize(nfre);
		err_Rhoxy[isite].resize(nfre); err_Rhoyx[isite].resize(nfre); err_Phaxy[isite].resize(nfre); err_Phayx[isite].resize(nfre);
		err_Rhoxy_ori[isite].resize(nfre); err_Rhoyx_ori[isite].resize(nfre); err_Phaxy_ori[isite].resize(nfre); err_Phayx_ori[isite].resize(nfre);
	}
	fout2 << nsite << " " << nfre << endl;
	fout3 << nsite << " " << nfre << endl;
	fout4 << nsite << " " << nfre << endl;
	///
	if (type == 1)
	{
	}
	else if (type == 2)
	{
		vector<int> _1D_structrue, _2D_structrue, TETM_ambiguty;
		_1D_structrue.resize(nsite); _2D_structrue.resize(nsite); TETM_ambiguty.resize(nsite);
		cerr << "nsite: " << nsite << " " << "nfre: " << nfre << endl;
		fout << "site" << " " << "freq" << " " << "beta" << " " << "strike" << " " << "lmbda" << " " << "PMAX" << " " << "PMIN" << endl;
		fo << "site" << " " << "freq" << " " << "t" << " " << "e" << " " << "si" << " " << "f1" << " " << "f1_init" << endl;
		fo2 << "site" << " " << "1D_structrue" << " " << "1D_part_start " << " " << "1D_part_end " << " " << "2D_structrue" << " " << "TETM_ambiguity" << " " << "Average_Strike" << endl;
		for (int isite = 0; isite < nsite; isite++)
		{
			cerr << endl;
			cerr << "-----------------------Site Number: " << isite + 1 << " is under processing------------------------------" << endl;
			cerr << endl;
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				fin >> site[isite] >> freq[ifre] >> X11[ifre] >> Y11[ifre] >> VarZ11[ifre] >> X12[ifre] >> Y12[ifre] >> VarZ12[ifre]
					>> X21[ifre] >> Y21[ifre] >> VarZ21[ifre] >> X22[ifre] >> Y22[ifre] >> VarZ22[ifre];
				//
				Rhoxy_ori[isite][ifre] = log10((X12[ifre] * X12[ifre] + Y12[ifre] * Y12[ifre]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
				Rhoyx_ori[isite][ifre] = log10((X21[ifre] * X21[ifre] + Y21[ifre] * Y21[ifre]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
				Phaxy_ori[isite][ifre] = atan(Y12[ifre] / X12[ifre]) * 180 / PI;
				Phayx_ori[isite][ifre] = atan(Y21[ifre] / X21[ifre]) * 180 / PI;
				err_Rhoxy_ori[isite][ifre] = 2 * sqrt(VarZ12[ifre]) / 796.1 / (sqrt(X12[ifre] * X12[ifre] + Y12[ifre] * Y12[ifre])) * 100 * 0.00434;
				err_Phaxy_ori[isite][ifre] = 2 * sqrt(VarZ12[ifre]) / 796.1 / (sqrt(X12[ifre] * X12[ifre] + Y12[ifre] * Y12[ifre])) * 100 * 0.285;
				err_Rhoyx_ori[isite][ifre] = 2 * sqrt(VarZ21[ifre]) / 796.1 / (sqrt(X21[ifre] * X21[ifre] + Y21[ifre] * Y21[ifre])) * 100 * 0.00434;
				err_Phayx_ori[isite][ifre] = 2 * sqrt(VarZ21[ifre]) / 796.1 / (sqrt(X21[ifre] * X21[ifre] + Y21[ifre] * Y21[ifre])) * 100 * 0.285;
				//calculate phase tensor
				double detX = X11[ifre] * X22[ifre] - X21[ifre] * X12[ifre];
				P11[ifre] = (X22[ifre] * Y11[ifre] - X12[ifre] * Y21[ifre]) / detX;
				P12[ifre] = (X22[ifre] * Y12[ifre] - X12[ifre] * Y22[ifre]) / detX;
				P21[ifre] = (X11[ifre] * Y21[ifre] - X21[ifre] * Y11[ifre]) / detX;
				P22[ifre] = (X11[ifre] * Y22[ifre] - X21[ifre] * Y12[ifre]) / detX;
				//calculte skew
				double a1 = P12[ifre] + P21[ifre];
				double a2 = P11[ifre] - P22[ifre];
				double b1 = P12[ifre] - P21[ifre];
				double b2 = P11[ifre] + P22[ifre];
				double as, bs;
				if (a1 * a2 < 0)
				{
					alpha[ifre] = (atan2(-abs(a1), abs(a2)));
					if (ifre > 0)
					{
						as = PI - abs(alpha[ifre]);
						if (abs(as - alpha[ifre - 1]) < abs(alpha[ifre] - alpha[ifre - 1]))
							alpha[ifre] = as;
					}
					alpha[ifre] = alpha[ifre] * 0.5;
				}
				else
				{
					alpha[ifre] = atan2(abs(a1), abs(a2));
					if (ifre > 0)
					{
						as = -(PI - abs(alpha[ifre]));
						if (abs(as - alpha[ifre - 1]) < abs(alpha[ifre] - alpha[ifre - 1]))
							alpha[ifre] = as;
					}
					alpha[ifre] = alpha[ifre] * 0.5;
				}
				if (b1 * b2 < 0)
				{
					beta[ifre] = (atan2(-abs(b1), abs(b2)));
					if (ifre > 0)
					{
						bs = PI - abs(beta[ifre]);
						if (abs(bs - beta[ifre - 1]) < abs(beta[ifre] - beta[ifre - 1]))
							beta[ifre] = bs;
					}
					beta[ifre] = beta[ifre] * 0.5;
				}
				else
				{
					beta[ifre] = atan2(abs(b1), abs(b2));
					if (ifre > 0)
					{
						bs = -(PI - abs(beta[ifre]));
						if (abs(bs - beta[ifre - 1]) < abs(beta[ifre] - beta[ifre - 1]))
							beta[ifre] = bs;
					}
					beta[ifre] = beta[ifre] * 0.5;
				}
				//
				PMAX[ifre] = 0.5 * (sqrt(pow(P11[ifre] - P22[ifre], 2) + pow(P12[ifre] + P21[ifre], 2)) + sqrt(pow(P11[ifre] + P22[ifre], 2) + pow(P12[ifre] - P21[ifre], 2)));
				PMIN[ifre] = 0.5 * (-sqrt(pow(P11[ifre] - P22[ifre], 2) + pow(P12[ifre] + P21[ifre], 2)) + sqrt(pow(P11[ifre] + P22[ifre], 2) + pow(P12[ifre] - P21[ifre], 2)));
				lmbda[ifre] = (PMAX[ifre] - PMIN[ifre]) / (PMAX[ifre] + PMIN[ifre]);
				strike[ifre] = alpha[ifre] - beta[ifre];
				if (strike[ifre] > PI / 2 && strike[ifre] <= PI)strike[ifre] = -strike[ifre] + PI;
				if (strike[ifre] < -PI / 2 && strike[ifre] >= -PI)strike[ifre] = strike[ifre] + PI;
			}
			//oridata
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				fout4 << site[isite] << " " << freq[ifre] << " " << (Rhoxy_ori[isite][ifre]) << " " << abs(Phaxy_ori[isite][ifre]) <<
					" " << (Rhoyx_ori[isite][ifre]) << " " << abs(Phayx_ori[isite][ifre]) << " " << abs(err_Rhoxy_ori[isite][ifre]) << " " << abs(err_Rhoyx_ori[isite][ifre])
					<< " " << abs(err_Phaxy_ori[isite][ifre]) << " " << abs(err_Phayx_ori[isite][ifre]) << endl;
			}
			//Distortion
			_1D_Frequency_part_seeking(oneD_frs[isite], oneD_fre[isite], nfre, lmbda, beta, _1D_limit, _2D_limit);
			_2D_Frequency_part_seeking(twoD_frs[isite], twoD_fre[isite], nfre, beta, strike, _2D_limit);
			if ((oneD_fre[isite] - oneD_frs[isite]) < 3)_1D_structrue[isite] = 0;
			else _1D_structrue[isite] = 1;
			if ((twoD_fre[isite] - twoD_frs[isite]) < 3)_2D_structrue[isite] = 0;
			else _2D_structrue[isite] = 1;
			TETM_ambiguty[isite] = 0;
			//get avarage strike
			alp_ave[isite] = 0;
			for (int ff = twoD_frs[isite]; ff < twoD_fre[isite]; ff++)
			{
				alp_ave[isite] += strike[ff];
			}
			alp_ave[isite] /= twoD_fre[isite] - twoD_frs[isite];
			//adjust
			if (alp_ave[isite] > PI / 4.)
				alp_ave[isite] = alp_ave[isite] - PI / 2.;
			if (alp_ave[isite] < -PI / 4.)
				alp_ave[isite] = alp_ave[isite] + PI / 2.;
			//Distortion start
			double R[2][2], RT[2][2], RX[2][2], RY[2][2];
			double X[2][2], RTXR[2][2], RTYR[2][2], XR[2][2], XRi[2][2], Y[2][2], YR[2][2], P[2][2];
			double t[2][2], D[2][2], result[2][2], DR[2][2], varD[2][2], D_tmp[2][2], RTD[2][2], Dn[2][2];
			double tmp[2][2];
			vector<double> varD11, varD12, varD21, varD22;
			double g1Dxy, g1Dyx, g2Dxy, g2Dyx;
			g1Dxy = 0; g1Dyx = 0; g2Dxy = 0; g2Dyx = 0;
			//Rotation	
			if (rot)
			{
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					//	strike[ifre] = alp_ave[isite];
					R[0][0] = cos(alp_ave[isite]);	R[0][1] = sin(alp_ave[isite]);	R[1][0] = -sin(alp_ave[isite]);	R[1][1] = cos(alp_ave[isite]);
					RT[0][0] = cos(alp_ave[isite]);	RT[0][1] = -sin(alp_ave[isite]);	RT[1][0] = sin(alp_ave[isite]);	RT[1][1] = cos(alp_ave[isite]);
					//rotation
					X[0][0] = X11[ifre]; X[0][1] = X12[ifre]; X[1][0] = X21[ifre]; X[1][1] = X22[ifre];
					Y[0][0] = Y11[ifre]; Y[0][1] = Y12[ifre]; Y[1][0] = Y21[ifre]; Y[1][1] = Y22[ifre];
					multiplyMatrices(R, X, RX);
					multiplyMatrices(RX, RT, X);
					multiplyMatrices(R, Y, RY);
					multiplyMatrices(RY, RT, Y);
					X11[ifre] = X[0][0]; X12[ifre] = X[0][1]; X21[ifre] = X[1][0]; X22[ifre] = X[1][1];
					Y11[ifre] = Y[0][0];  Y12[ifre] = Y[0][1];  Y21[ifre] = Y[1][0]; Y22[ifre] = Y[1][1];
					double detX = X11[ifre] * X22[ifre] - X21[ifre] * X12[ifre];
					P11[ifre] = (X22[ifre] * Y11[ifre] - X12[ifre] * Y21[ifre]) / detX;
					P12[ifre] = (X22[ifre] * Y12[ifre] - X12[ifre] * Y22[ifre]) / detX;
					P21[ifre] = (X11[ifre] * Y21[ifre] - X21[ifre] * Y11[ifre]) / detX;
					P22[ifre] = (X11[ifre] * Y22[ifre] - X21[ifre] * Y12[ifre]) / detX;
				}
			}
			//1D
			t[0][0] = 0; t[0][1] = -1; t[1][0] = 1; t[1][1] = 0;
			D[0][0] = 0; D[0][1] = 0; D[1][0] = 0; D[1][1] = 0;

			if ((dist == 1 || dist == 3))
			{
				///1D Distortion
				//Starting distortion			
				for (int ifre = oneD_frs[isite]; ifre < oneD_fre[isite]; ifre++)
				{
					X[0][0] = X11[ifre]; X[0][1] = X12[ifre]; X[1][0] = X21[ifre]; X[1][1] = X22[ifre];
					multiplyMatrices(X, t, result);
					for (int i = 0; i < 2; i++)
						for (int j = 0; j < 2; j++)
						{
							D_tmp[i][j] = 2 * result[i][j] / (X12[ifre] - X21[ifre]);
							D[i][j] += 2 * result[i][j] / (X12[ifre] - X21[ifre]);
						}
					varD11.push_back(D_tmp[0][0]); varD12.push_back(D_tmp[0][1]);
					varD21.push_back(D_tmp[1][0]); varD22.push_back(D_tmp[1][1]);
				}
				varD[0][0] = calculateStandardDeviation(varD11); varD[0][1] = calculateStandardDeviation(varD12);
				varD[1][0] = calculateStandardDeviation(varD21); varD[1][1] = calculateStandardDeviation(varD22);
				for (int i = 0; i < 2; i++)
					for (int j = 0; j < 2; j++)
					{
						D[i][j] /= oneD_fre[isite] - oneD_frs[isite];
					}
				////
				cerr << endl;
				cerr << "1D-Distortion Matrix :" << endl;
				cerr << "[ " << D[0][0] << " var: " << varD[0][0] << " , " << D[0][1] << " var: " << varD[0][1] << " ]" << endl;
				cerr << "[ " << D[1][0] << " var: " << varD[1][0] << " , " << D[1][1] << " var: " << varD[1][1] << " ]" << endl;
				cerr << endl;
				////	
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					X[0][0] = X11[ifre]; X[0][1] = X12[ifre]; X[1][0] = X21[ifre]; X[1][1] = X22[ifre];
					Y[0][0] = Y11[ifre]; Y[0][1] = Y12[ifre]; Y[1][0] = Y21[ifre]; Y[1][1] = Y22[ifre];
					P[0][0] = P11[ifre]; P[0][1] = P12[ifre]; P[1][0] = P21[ifre]; P[1][1] = P22[ifre];
					inv_multiplyMatrices(D, X, XR);
					multiplyMatrices(XR, P, YR);
					Rhoxy_1D[isite][ifre] = log10((XR[0][1] * XR[0][1] + YR[0][1] * YR[0][1]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
					Rhoyx_1D[isite][ifre] = log10((XR[1][0] * XR[1][0] + YR[1][0] * YR[1][0]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
					Phaxy_1D[isite][ifre] = atan(YR[0][1] / XR[0][1]) * 180 / PI;
					Phayx_1D[isite][ifre] = atan(YR[1][0] / XR[1][0]) * 180 / PI;
					fout2 << site[isite] << " " << freq[ifre] << " " << (Rhoxy_1D[isite][ifre]) << " " << abs(Phaxy_1D[isite][ifre]) << " " << (Rhoyx_1D[isite][ifre]) << " " << abs(Phayx_1D[isite][ifre]) << endl;
					if (ifre >= oneD_frs[isite] && ifre < oneD_fre[isite])
					{
						g1Dxy = g1Dxy + Rhoxy_1D[isite][ifre];
						g1Dyx = g1Dyx + Rhoyx_1D[isite][ifre];
					}
				}
				if (_1D_structrue[isite] != 0)
				{
					g1Dxy /= oneD_fre[isite] - oneD_frs[isite];
					g1Dyx /= oneD_fre[isite] - oneD_frs[isite];
				}
				else
				{
					g1Dxy = 0;
					g1Dyx = 0;
				}
			}
			//2D
			DR[0][0] = 0; DR[0][1] = 0; DR[1][0] = 0; DR[1][1] = 0;
			t[0][0] = 0; t[0][1] = -1; t[1][0] = 1; t[1][1] = 0;
			D[0][0] = 0; D[0][1] = 0; D[1][0] = 0; D[1][1] = 0;
			if ((dist == 2 || dist == 3))
			{
				//	2D-Distortion
				//Starting distortion
				vector<double> varD11, varD12, varD21, varD22;
				cerr << endl;
				cerr << "Average azimuth angle: " << alp_ave[isite] * 180. / PI << endl;
				R[0][0] = cos(alp_ave[isite]);	R[0][1] = sin(alp_ave[isite]);	R[1][0] = -sin(alp_ave[isite]);	R[1][1] = cos(alp_ave[isite]);
				RT[0][0] = cos(alp_ave[isite]);	RT[0][1] = -sin(alp_ave[isite]);	RT[1][0] = sin(alp_ave[isite]);	RT[1][1] = cos(alp_ave[isite]);
				for (int ifre = twoD_frs[isite]; ifre < twoD_fre[isite]; ifre++)
				{
					X[0][0] = X11[ifre]; X[0][1] = X12[ifre]; X[1][0] = X21[ifre]; X[1][1] = X22[ifre];
					double sign = (X[0][1] * X[1][0]);
					double R = sgn(sign) * sqrt((X[0][1] * X[0][1] + X[1][1] * X[1][1]) / (X[0][0] * X[0][0] + X[1][0] * X[1][0]));
					double X_parallel, X_perpendicular;
					X_parallel = 0.5 * (X[0][1] + X[1][0] * R);
					X_perpendicular = 0.5 * (X[1][0] + X[0][1] / R);
					//
					XRi[0][0] = 0; XRi[0][1] = 1. / X_perpendicular; XRi[1][0] = 1. / X_parallel; XRi[1][1] = 0;
					multiplyMatrices(X, XRi, result);
					for (int i = 0; i < 2; i++)
						for (int j = 0; j < 2; j++)
						{
							D_tmp[i][j] = result[i][j];
							D[i][j] += result[i][j];
						}
					varD11.push_back(D_tmp[0][0]); varD12.push_back(D_tmp[0][1]);
					varD21.push_back(D_tmp[1][0]); varD22.push_back(D_tmp[1][1]);
				}
				//
				varD[0][0] = calculateStandardDeviation(varD11); varD[0][1] = calculateStandardDeviation(varD12);
				varD[1][0] = calculateStandardDeviation(varD21); varD[1][1] = calculateStandardDeviation(varD22);
				for (int i = 0; i < 2; i++)
					for (int j = 0; j < 2; j++)
					{
						D[i][j] /= twoD_fre[isite] - twoD_frs[isite];
					}
				cerr << endl;
				cerr << "2D-Distortion Matrix :" << endl;
				cerr << "[ " << D[0][0] << " var: " << varD[0][0] << " , " << D[0][1] << " var: " << varD[0][1] << " ]" << endl;
				cerr << "[ " << D[1][0] << " var: " << varD[1][0] << " , " << D[1][1] << " var: " << varD[1][1] << " ]" << endl;
				cerr << endl;
				if (D[1][1] > D[0][0])TETM_ambiguty[isite] = 1;
				//4*2
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					fin1 >> site[isite] >> freq[ifre] >> X11[ifre] >> Y11[ifre] >> VarZ11[ifre] >> X12[ifre] >> Y12[ifre] >> VarZ12[ifre]
						>> X21[ifre] >> Y21[ifre] >> VarZ21[ifre] >> X22[ifre] >> Y22[ifre] >> VarZ22[ifre];
					VarZ11[ifre] = sqrt(VarZ11[ifre]) / 796.1;
					VarZ12[ifre] = sqrt(VarZ12[ifre]) / 796.1;
					VarZ21[ifre] = sqrt(VarZ21[ifre]) / 796.1;
					VarZ22[ifre] = sqrt(VarZ22[ifre]) / 796.1;
					//calculate phase tensor
					double detX = X11[ifre] * X22[ifre] - X21[ifre] * X12[ifre];
					P11[ifre] = (X22[ifre] * Y11[ifre] - X12[ifre] * Y21[ifre]) / detX;
					P12[ifre] = (X22[ifre] * Y12[ifre] - X12[ifre] * Y22[ifre]) / detX;
					P21[ifre] = (X11[ifre] * Y21[ifre] - X21[ifre] * Y11[ifre]) / detX;
					P22[ifre] = (X11[ifre] * Y22[ifre] - X21[ifre] * Y12[ifre]) / detX;
				}
				//
				vector<double> x_42, x0_42, Zobs_42;
				x_42.resize(3); x0_42.resize(3);  Zobs_42.resize(16);
				double lb = std::max(-PI / 2., alp_ave[isite] - PI / 2.);
				double ub = std::min(PI / 2., alp_ave[isite] + PI / 2.);
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					x0_42[0] = 0.5 * (D[1][0] - D[0][1]);//t
					x0_42[1] = 0.5 * (D[1][0] + D[0][1]);//e
					if (ifre < 1)x0_42[2] = alp_ave[isite];//si
					else x0_42[2] = strike_42[ifre - 1];//si
					//x0_42[2] =alp_ave[isite];//si
					if (ifre < 1)
					{
						lb = std::max(-PI / 2., alp_ave[isite] - PI / 2.);
						ub = std::min(PI / 2., alp_ave[isite] + PI / 2.);
					}
					else
					{
						lb = std::max(-PI / 2., strike_42[ifre - 1] - PI / 18.);
						ub = std::min(PI / 2., strike_42[ifre - 1] + PI / 18.);
					}
					//		x0_42[2] = alp_ave[isite];//si
							////
					Zobs_42[0] = X11[ifre]; Zobs_42[1] = Y11[ifre]; Zobs_42[2] = X12[ifre]; Zobs_42[3] = Y12[ifre];
					Zobs_42[4] = X21[ifre]; Zobs_42[5] = Y21[ifre]; Zobs_42[6] = X22[ifre]; Zobs_42[7] = Y22[ifre];
					if (ifre < nfre - 1)
					{
						Zobs_42[8] = X11[ifre + 1]; Zobs_42[9] = Y11[ifre + 1]; Zobs_42[10] = X12[ifre + 1]; Zobs_42[11] = Y12[ifre + 1];
						Zobs_42[12] = X21[ifre + 1]; Zobs_42[13] = Y21[ifre + 1]; Zobs_42[14] = X22[ifre + 1]; Zobs_42[15] = Y22[ifre + 1];
					}
					else
					{
						Zobs_42[8] = X11[ifre - 1]; Zobs_42[9] = Y11[ifre - 1]; Zobs_42[10] = X12[ifre - 1]; Zobs_42[11] = Y12[ifre - 1];
						Zobs_42[12] = X21[ifre - 1]; Zobs_42[13] = Y21[ifre - 1]; Zobs_42[14] = X22[ifre - 1]; Zobs_42[15] = Y22[ifre - 1];
					}
					//
					SimulatedAnnealing_4_2(x_42, Zobs_42, x0_42, lb, ub, 2);
					strike_42[ifre] = x_42[2];//si
				}
				//////adjust strike
				if (smooth_strike != 0)
				{
					gaussianSmooth(strike_42, strike, nfre, 4);
				}
				else
				{
					for (int ifre = 0; ifre < nfre; ifre++)strike[ifre] = strike_42[ifre];
				}
				//
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					fout << site[isite] << " " << freq[ifre] << " " << beta[ifre] * 180. / PI << " " << strike[ifre] * 180. / PI << " " << lmbda[ifre] << " " <<
						1 / coeff << "c " << PMIN[ifre] / PMAX[ifre] / coeff << "c" << endl;
				}
				//get avarage strike
				alp_ave[isite] = 0;
				for (int ff = twoD_frs[isite]; ff < twoD_fre[isite]; ff++)
				{
					alp_ave[isite] += strike[ff];
				}
				alp_ave[isite] /= twoD_fre[isite] - twoD_frs[isite];
				cerr << endl;
				cerr << "Average azimuth angle after 4*2: " << alp_ave[isite] * 180. / PI << endl;
				//
				Matrix2cd Zobs;
				Matrix2d Rr;
				Matrix2d Dd;
				Matrix2cd Z2D;
				Dd.coeffRef(0, 0) = D[0][0];	Dd.coeffRef(0, 1) = D[0][1];	Dd.coeffRef(1, 0) = D[1][0];	Dd.coeffRef(1, 1) = D[1][1];
				vector<double> obj, objs;
				vector< vector<double> > x0, x, l, u, Z, VarZ;
				obj.resize(nfre); objs.resize(nfre);
				x0.resize(nfre); x.resize(nfre); l.resize(nfre); u.resize(nfre); VarZ.resize(nfre); Z.resize(nfre);

				for (int ifre = 0; ifre < nfre; ifre++)
				{
					x0[ifre].resize(7); x[ifre].resize(7); l[ifre].resize(7); u[ifre].resize(7); VarZ[ifre].resize(4); Z[ifre].resize(8);
					x0[ifre][0] = 0.5 * (D[1][0] - D[0][1]);//t
					x0[ifre][1] = 0.5 * (D[1][0] + D[0][1]);//e
					x0[ifre][2] = strike[ifre];//si
					//x0[ifre][2] = alp_ave[isite];//si
					////
					Z[ifre][0] = X11[ifre]; Z[ifre][1] = Y11[ifre]; Z[ifre][2] = X12[ifre]; Z[ifre][3] = Y12[ifre];
					Z[ifre][4] = X21[ifre]; Z[ifre][5] = Y21[ifre]; Z[ifre][6] = X22[ifre]; Z[ifre][7] = Y22[ifre];
					Zobs.real().coeffRef(0, 0) = X11[ifre]; Zobs.real().coeffRef(0, 1) = X12[ifre]; Zobs.real().coeffRef(1, 0) = X21[ifre]; Zobs.real().coeffRef(1, 1) = X22[ifre];
					Zobs.imag().coeffRef(0, 0) = Y11[ifre]; Zobs.imag().coeffRef(0, 1) = Y12[ifre]; Zobs.imag().coeffRef(1, 0) = Y21[ifre]; Zobs.imag().coeffRef(1, 1) = Y22[ifre];
					//
					Rr.coeffRef(0, 0) = cos(x0[ifre][2]);	Rr.coeffRef(0, 1) = -sin(x0[ifre][2]);	Rr.coeffRef(1, 0) = sin(x0[ifre][2]);	Rr.coeffRef(1, 1) = cos(x0[ifre][2]);
					Z2D = Dd.inverse() * Rr.transpose() * Zobs * Rr;
					x0[ifre][3] = Z2D.real().coeffRef(0, 1); x0[ifre][4] = Z2D.imag().coeffRef(0, 1);
					x0[ifre][5] = Z2D.real().coeffRef(1, 0); x0[ifre][6] = Z2D.imag().coeffRef(1, 0);
					//
					/*l[ifre][0] = std::max(-1., bound(x0[ifre][0], 50, 1)); l[ifre][1] = std::max(-1., bound(x0[ifre][1], 50, 1)); l[ifre][2] = -PI / 2.;
					u[ifre][0] = std::min(1., bound(x0[ifre][0], 50, 2)); u[ifre][1] = std::min(1., bound(x0[ifre][1], 50, 2));  u[ifre][2] = PI / 2.;*/
					l[ifre][0] = -1; l[ifre][1] = -1; l[ifre][2] = x0[ifre][2] - PI / 1000000.;
					u[ifre][0] = 1; u[ifre][1] = 1;  u[ifre][2] = x0[ifre][2] + PI / 1000000.;
					for (int i = 3; i < 5; i++)
					{
						l[ifre][i] = std::min(bound(x0[ifre][i], 2 * abs(VarZ12[ifre] / Z[ifre][i - 1] * 100), 1), bound(x0[ifre][i], 20, 1));
						u[ifre][i] = std::max(bound(x0[ifre][i], 2 * abs(VarZ12[ifre] / Z[ifre][i - 1] * 100), 2), bound(x0[ifre][i], 20, 2));
					}
					for (int i = 5; i < 7; i++)
					{
						l[ifre][i] = std::min(bound(x0[ifre][i], 2 * abs(VarZ21[ifre] / Z[ifre][i - 1] * 100), 1), bound(x0[ifre][i], 20, 1));
						u[ifre][i] = std::max(bound(x0[ifre][i], 2 * abs(VarZ21[ifre] / Z[ifre][i - 1] * 100), 2), bound(x0[ifre][i], 20, 2));
					}
				}

				//8*7
				if (SA != 0)
				{
					if (_2D_structrue[isite] != 0)Yu_simulatedAnnealing(x, Z, VarZ, x0, freq, smooth, l, u, obj, objs, 0, 80);
				}
				else
				{
					for (int ifre = 0; ifre < nfre; ifre++)
						for (int i = 0; i < 7; i++)
						{
							x[ifre][i] = x0[ifre][i];
						}
				}
				//
				g2Dxy = 0; g2Dyx = 0;
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					fo << site[isite] << " " << freq[ifre] << " " << x[ifre][0] << " " << x[ifre][1] << " " << x0[ifre][2] * 180 / PI << " " << (obj[ifre]) << " " << (objs[ifre]) << endl;
					Rhoxy[isite][ifre] = log10((x[ifre][3] * x[ifre][3] + x[ifre][4] * x[ifre][4]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])) / ec);
					Rhoyx[isite][ifre] = log10((x[ifre][5] * x[ifre][5] + x[ifre][6] * x[ifre][6]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])) / ec);
					Phaxy[isite][ifre] = atan(x[ifre][4] / x[ifre][3]);
					Phayx[isite][ifre] = atan(x[ifre][6] / x[ifre][5]);
					if (ifre >= oneD_frs[isite] && ifre < oneD_fre[isite])
					{
						g2Dxy = g2Dxy + Rhoxy[isite][ifre];
						g2Dyx = g2Dyx + Rhoyx[isite][ifre];
					}
				}
				g2Dxy /= oneD_fre[isite] - oneD_frs[isite];
				g2Dyx /= oneD_fre[isite] - oneD_frs[isite];
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					if (_2D_structrue[isite] != 0)
					{
						if (g1Dxy == 0 || g1Dyx == 0)
						{
							Rhoxy[isite][ifre] = Rhoxy[isite][ifre];
							Rhoyx[isite][ifre] = Rhoyx[isite][ifre];
						}
						else
						{
							Rhoxy[isite][ifre] = Rhoxy[isite][ifre] + g1Dxy - g2Dxy;
							Rhoyx[isite][ifre] = Rhoyx[isite][ifre] + g1Dyx - g2Dyx;
						}

						err_Rhoxy[isite][ifre] = 2 * (VarZ12[ifre]) / (sqrt(x[ifre][3] * x[ifre][3] + x[ifre][4] * x[ifre][4])) * 100 * 0.00434;
						err_Phaxy[isite][ifre] = 2 * (VarZ12[ifre]) / (sqrt(x[ifre][3] * x[ifre][3] + x[ifre][4] * x[ifre][4])) * 100 * 0.285;
						err_Rhoyx[isite][ifre] = 2 * (VarZ21[ifre]) / (sqrt(x[ifre][5] * x[ifre][5] + x[ifre][6] * x[ifre][6])) * 100 * 0.00434;
						err_Phayx[isite][ifre] = 2 * (VarZ21[ifre]) / (sqrt(x[ifre][5] * x[ifre][5] + x[ifre][6] * x[ifre][6])) * 100 * 0.285;
						fout3 << site[isite] << " " << freq[ifre] << " " << (Rhoxy[isite][ifre]) << " " << abs(Phaxy[isite][ifre] * 180 / PI) << " " << (Rhoyx[isite][ifre]) << " "
							<< abs(Phayx[isite][ifre] * 180 / PI) << " " << abs(err_Rhoxy[isite][ifre]) << " " << abs(err_Rhoyx[isite][ifre])
							<< " " << abs(err_Phaxy[isite][ifre]) << " " << abs(err_Phayx[isite][ifre]) << endl;
					}
					else
					{
						fout3 << site[isite] << " " << freq[ifre] << " " << "0" << " " << "0" << " " << "0" << " " << "0" << " " << "0" << " " << "0" << " " << "0" << " " << "0" << endl;
					}
				}
			}
			fo2 << site[isite] << " " << _1D_structrue[isite] << " " << oneD_frs[isite] << " " << oneD_fre[isite] << " " << _2D_structrue[isite] << " " << TETM_ambiguty[isite] << " " << alp_ave[isite] * 180 / PI << endl;
		}
		fin1.close(); fin.close(); fout3.close(); fout4.close();
		fout.close(); fout2.close(); fo.close(); fo2.close();
	}
	else
	{
		cerr << "TYPE WRONG!" << endl;
		exit(1);
	}

}