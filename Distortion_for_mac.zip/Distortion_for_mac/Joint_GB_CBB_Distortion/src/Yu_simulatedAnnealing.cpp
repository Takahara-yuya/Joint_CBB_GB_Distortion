/*
***********************************************************************

Yu_simulatedAnnealing.cpp

***********************************************************************

May 21, 2024
Copyright 2024

Zuwei Huang
hzw1498218560@tongji.edu.cn
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

Reference:
[1]Bibby, H.M., Caldwell, T.G. and Brown, C. (2005), Determinable and non-determinable parameters of galvanic distortion in magnetotellurics.
	 Geophysical Journal International, 163: 915-930. https://doi.org/10.1111/j.1365-246X.2005.02779.x
[2]Caldwell, T.G., Bibby, H.M. and Brown, C. (2004), The magnetotelluric phase tensor.
	 Geophysical Journal International, 158: 457-469. https://doi.org/10.1111/j.1365-246X.2004.02281.x

version 2.0.0

* ***********************************************************************
*/
#include "../include/CommonHeaders.h"
#include "../include/Yu_simulatedAnnealing.h"

void multiplyMatrices(double A[2][2], double B[2][2], double result[2][2])
{
	int n = 2;
	// Initialize result matrix with zeros
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			result[i][j] = 0;
		}
	}
	result[0][0] = (A[0][0] * B[0][0] + A[0][1] * B[1][0]);
	result[0][1] = (A[0][0] * B[0][1] + A[0][1] * B[1][1]);
	result[1][0] = (A[1][0] * B[0][0] + A[1][1] * B[1][0]);
	result[1][1] = (A[1][0] * B[0][1] + A[1][1] * B[1][1]);
}

void inv_multiplyMatrices(double A[2][2], double B[2][2], double result[2][2])
{
	int n = 2;
	// Initialize result matrix with zeros
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			result[i][j] = 0;
		}
	}
	double detA = A[0][0] * A[1][1] - A[1][0] * A[0][1];
	result[0][0] = (A[1][1] * B[0][0] - A[0][1] * B[1][0]) / detA;
	result[0][1] = (A[1][1] * B[0][1] - A[0][1] * B[1][1]) / detA;
	result[1][0] = (A[0][0] * B[1][0] - A[1][0] * B[0][0]) / detA;
	result[1][1] = (A[0][0] * B[1][1] - A[1][0] * B[0][1]) / detA;
}

bool invertMatrix(double matrix[2][2], double inverse[2][2])
{
	double det = determinant(matrix);
	if (det == 0) {
		cout << "Matrix is singular and cannot be inverted." << endl;
		return false;
	}

	// Calculate the inverse using the formula for 2x2 matrix
	inverse[0][0] = matrix[1][1] / det;
	inverse[0][1] = -matrix[0][1] / det;
	inverse[1][0] = -matrix[1][0] / det;
	inverse[1][1] = matrix[0][0] / det;

	return true;
}

double determinant(double matrix[2][2]) {
	return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
}

double sgn(double a)
{
	if (a > 0)
		return 1.0;
	else if (a == 0)
		return 0;
	else
		return -1.0;
}

double calculateMean(const std::vector<double>& data) {
	double sum = 0.0;
	for (double value : data) {
		sum += value;
	}
	return sum / data.size();
}

// �����׼��ĺ���
double calculateStandardDeviation(const std::vector<double>& data) {
	double mean = calculateMean(data);
	double sumOfSquares = 0.0;

	for (double value : data) {
		sumOfSquares += std::pow(value - mean, 2);
	}

	double variance = sumOfSquares / data.size();
	return std::sqrt(variance);
}

void objectiveFunction_Mul(vector< vector<double> >& x, vector< vector<double> > Zobs, vector< vector<double> > Zvar, double* freq, double smooth, vector<double>& e
	, double& R)
{
	int nfre = x.size();//nsite
	int N = x[0].size();//parameter
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		e[ifre] = 0;
		Matrix2d R;
		Matrix2d T, E, D;
		Matrix2cd Z2D, Zcal, Zob;
		double t = x[ifre][0];
		double ee = x[ifre][1];
		double si = x[ifre][2];
		T.coeffRef(0, 0) = 1;	T.coeffRef(0, 1) = -t;	T.coeffRef(1, 0) = t;	T.coeffRef(1, 1) = 1;
		E.coeffRef(0, 0) = 1;	E.coeffRef(0, 1) = ee;	E.coeffRef(1, 0) = ee;	E.coeffRef(1, 1) = 1;
		D = T * E;
		R.coeffRef(0, 0) = cos(si);	R.coeffRef(0, 1) = -sin(si);	R.coeffRef(1, 0) = sin(si);	R.coeffRef(1, 1) = cos(si);
		///
		Z2D.setZero();
		Z2D.real().coeffRef(0, 1) = x[ifre][3]; Z2D.imag().coeffRef(0, 1) = x[ifre][4];
		Z2D.real().coeffRef(1, 0) = x[ifre][5]; Z2D.imag().coeffRef(1, 0) = x[ifre][6];
		Zob.real().coeffRef(0, 0) = Zobs[ifre][0]; Zob.imag().coeffRef(0, 0) = Zobs[ifre][1];
		Zob.real().coeffRef(0, 1) = Zobs[ifre][2]; Zob.imag().coeffRef(0, 1) = Zobs[ifre][3];
		Zob.real().coeffRef(1, 0) = Zobs[ifre][4]; Zob.imag().coeffRef(1, 0) = Zobs[ifre][5];
		Zob.real().coeffRef(1, 1) = Zobs[ifre][6]; Zob.imag().coeffRef(1, 1) = Zobs[ifre][7];
		Zcal = R * D * Z2D * R.transpose();
		///
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				e[ifre] += pow(log10(pow(abs(Zob.coeffRef(i, j)), 2) / pow(abs(Zcal.coeffRef(i, j)), 2)), 2);
			}
		}
	}
	//smooth
	R = 0;
	vector<double> Rhoxy, Rhoyx, Phaxy, Phayx;
	Rhoxy.resize(nfre); Rhoyx.resize(nfre); Phaxy.resize(nfre); Phayx.resize(nfre);
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		Rhoxy[ifre] = log10((x[ifre][3] * x[ifre][3] + x[ifre][4] * x[ifre][4]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
		Rhoyx[ifre] = log10((x[ifre][5] * x[ifre][5] + x[ifre][6] * x[ifre][6]) / (4 * PI * 0.0000001 * 2 * PI * pow(10, freq[ifre])));
		Phaxy[ifre] = abs(atan(x[ifre][4] / x[ifre][3]));
		Phayx[ifre] = abs(atan(x[ifre][6] / x[ifre][5]));
	}
	for (int ifre = 1; ifre < nfre; ifre++)
	{
		R += pow((Rhoxy[ifre] - Rhoxy[ifre - 1]), 2) + pow((Rhoyx[ifre] - Rhoyx[ifre - 1]), 2) + 1.5 * pow((Phaxy[ifre] - Phaxy[ifre - 1]), 2)
			+ 1.5 * pow((Phayx[ifre] - Phayx[ifre - 1]), 2);
	}
	R = smooth * R;
}

double objectiveFunction_4_2(vector<double>& x, vector<double> Zobs, int count)
{
	Matrix2d R;
	Matrix2d T, E, D;
	Matrix2cd Z2D, Z2D2;
	Matrix2cd Zob, Zob2;
	double t = x[0];
	double e = x[1];
	double si = x[2];
	Zob.real().coeffRef(0, 0) = Zobs[0]; Zob.imag().coeffRef(0, 0) = Zobs[1];
	Zob.real().coeffRef(0, 1) = Zobs[2]; Zob.imag().coeffRef(0, 1) = Zobs[3];
	Zob.real().coeffRef(1, 0) = Zobs[4]; Zob.imag().coeffRef(1, 0) = Zobs[5];
	Zob.real().coeffRef(1, 1) = Zobs[6]; Zob.imag().coeffRef(1, 1) = Zobs[7];
	Zob2.real().coeffRef(0, 0) = Zobs[8]; Zob2.imag().coeffRef(0, 0) = Zobs[9];
	Zob2.real().coeffRef(0, 1) = Zobs[10]; Zob2.imag().coeffRef(0, 1) = Zobs[11];
	Zob2.real().coeffRef(1, 0) = Zobs[12]; Zob2.imag().coeffRef(1, 0) = Zobs[13];
	Zob2.real().coeffRef(1, 1) = Zobs[14]; Zob2.imag().coeffRef(1, 1) = Zobs[15];
	T.coeffRef(0, 0) = 1;	T.coeffRef(0, 1) = -t;	T.coeffRef(1, 0) = t;	T.coeffRef(1, 1) = 1;
	E.coeffRef(0, 0) = 1;	E.coeffRef(0, 1) = e;	E.coeffRef(1, 0) = e;	E.coeffRef(1, 1) = 1;
	D = T * E;
	R.coeffRef(0, 0) = cos(si);	R.coeffRef(0, 1) = -sin(si);	R.coeffRef(1, 0) = sin(si);	R.coeffRef(1, 1) = cos(si);
	Z2D = D.inverse() * R.transpose() * Zob * R;
	Z2D2 = D.inverse() * R.transpose() * Zob2 * R;
	///4*2 obj
	double e1;
	if (count > 1)
	{
		e1 = Z2D.real().coeffRef(0, 0) * Z2D.real().coeffRef(0, 0) +
			Z2D.real().coeffRef(1, 1) * Z2D.real().coeffRef(1, 1) +
			Z2D.imag().coeffRef(0, 0) * Z2D.imag().coeffRef(0, 0) +
			Z2D.imag().coeffRef(1, 1) * Z2D.imag().coeffRef(1, 1) +
			Z2D2.real().coeffRef(0, 0) * Z2D2.real().coeffRef(0, 0) +
			Z2D2.real().coeffRef(1, 1) * Z2D2.real().coeffRef(1, 1) +
			Z2D2.imag().coeffRef(0, 0) * Z2D2.imag().coeffRef(0, 0) +
			Z2D2.imag().coeffRef(1, 1) * Z2D2.imag().coeffRef(1, 1);
	}
	else
	{
		e1 = Z2D.real().coeffRef(0, 0) * Z2D.real().coeffRef(0, 0) +
			Z2D.real().coeffRef(1, 1) * Z2D.real().coeffRef(1, 1) +
			Z2D.imag().coeffRef(0, 0) * Z2D.imag().coeffRef(0, 0) +
			Z2D.imag().coeffRef(1, 1) * Z2D.imag().coeffRef(1, 1);
	}

	return e1;
}

void randomVector(vector<double>& rd, double upb, double lwb)
{
	int N = rd.size();
	for (int i = 0; i < N; i++)
	{
		rd[i] = randomDouble(upb, lwb);
	}
}

double randomDouble(double upb, double lwb)
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::uniform_real_distribution<double> dis(lwb, upb);
	return dis(gen);
}

void smoothArray(double* arr, int size, int windowSize) {
	// 
	if (windowSize % 2 == 0) {
		windowSize++;
	}

	int halfWindow = windowSize / 2;

	for (int i = 0; i < size; ++i) {
		int start = std::max(0, i - halfWindow);
		int end = std::min(size - 1, i + halfWindow);
		double sum = 0.0;
		int count = 0;
		for (int j = start; j <= end; ++j) {
			sum += arr[j];
			count++;
		}
		arr[i] = sum / count;
	}
}

void Yu_simulatedAnnealing(vector< vector<double> >& x, vector< vector<double> > Zobs, vector< vector<double> > Zvar, vector< vector<double> >& x0,
	double* freq, double smooth, vector< vector<double> >& l, vector< vector<double> >& u, vector<double>& obj, vector<double>& obj_s, int fres, int free)
{
	cerr << std::endl;
	static std::random_device rd1;
	static std::mt19937 gen2(rd1());
	static std::uniform_real_distribution<double> dis2(0.0, 1.0);

	auto start_time = std::chrono::high_resolution_clock::now();
	///
	double R, R1;
	double temp0 = 100.;
	int jtemp = 1;
	int maxtemps = 250000;
	double decay = 0.98;
	int nmov = 2;
	double q0 = -5;
	const int percent_step = maxtemps / 5.;  // ÿ20%�Ĳ�����
	///
	vector<double>e1, e2;
	double emod, etrial, de, dde, arg, rd;
	int nfre = x.size();//nsite
	int N = x[0].size();//parameter
	e1.resize(nfre); e2.resize(nfre);
	objectiveFunction_Mul(x0, Zobs, Zvar, freq, smooth, e1, R);
	emod = calculateMean(e1) + R;
	//
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		obj_s[ifre] = e1[ifre];
	}
	temp0 = std::max(40000 * emod, temp0);
	///
	double temp, tmp;
	vector< vector<double> > t0, x2;
	t0.resize(nfre); x.resize(nfre); x2.resize(nfre);
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		t0[ifre].resize(N); x[ifre].resize(N); x2[ifre].resize(N);
		for (int i = 0; i < N; i++)
		{
			t0[ifre][i] = temp0;
			x[ifre][i] = x0[ifre][i];
		}
	}
	//ofstream fout1("Yu_SA.dat");
	while (true)
	{
		temp = temp0 * exp(-decay * pow(jtemp - 1, 0.5));
		//
		jtemp++;
		if (jtemp > maxtemps)break;
		if (jtemp % percent_step == 0) {
			int percent_complete = jtemp * 100 / maxtemps;
			std::cerr << "Regional 8*7 Yu_simulatedAnnealing Completed: " << percent_complete << "%" << std::endl;
		}
		//
		for (int jmov = 0; jmov < nmov; jmov++)
		{
			//if (jtemp < 5000)fout1 << jtemp << " " << emod << endl;
			//pertubation
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				if (ifre >= fres && ifre < free)
				{
					for (int i = 0; i < N; i++)
					{
						tmp = t0[ifre][i] * exp(-decay * pow(jtemp - 1, 0.5));
						x2[ifre][i] = Walk(x[ifre][i], l[ifre][i], u[ifre][i], tmp);
					}
				}
				else
				{
					for (int i = 0; i < N; i++)
					{
						x2[ifre][i] = x[ifre][i];
					}
				}
			}
			//calculate obj
			objectiveFunction_Mul(x2, Zobs, Zvar, freq, smooth, e2, R1);
			etrial = calculateMean(e2) + R1;
			de = etrial - emod;
			if (de < 0)//acceptence
			{
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					for (int i = 0; i < N; i++)
					{
						x[ifre][i] = x2[ifre][i];
					}
				}
				emod = etrial;
				for (int ifre = 0; ifre < nfre; ifre++)
				{
					obj[ifre] = e2[ifre];
				}
			}
			else //acceptence with 
			{
				rd = dis2(gen2);
				dde = 1. + (q0 - 1.) * de / temp;
				if (dde <= 0.)dde = 0.;
				arg = pow(dde, 1. / (1. - q0));
				if (arg > rd)
				{
					for (int ifre = 0; ifre < nfre; ifre++)
					{
						for (int i = 0; i < N; i++)
						{
							x[ifre][i] = x2[ifre][i];
						}
					}
					emod = etrial;
					for (int ifre = 0; ifre < nfre; ifre++)
					{
						obj[ifre] = e2[ifre];
					}
				}
			}
		}
	}
	cerr << endl;
	auto end_time = std::chrono::high_resolution_clock::now();
	auto duration = std::chrono::duration_cast<std::chrono::seconds>(end_time - start_time);
	cerr << "SimulatedAnnealing costs time: " << duration.count() << " s" << endl;
	cerr << endl;
}

void SimulatedAnnealing_4_2(vector<double>& xo, vector<double> Zobs, vector<double>& x0
	, double l, double u, int count)
{
	double Ti, mu, rand;
	double q = 0.9;
	int kmax = 5000;
	double TolFun = 1E-16;
	int k = 0;
	///
	vector<double> dx, rd, x1, x;
	double df, fx1, fx, fo;
	int N = x0.size();
	x1 = x0;
	x = x0;
	fx = objectiveFunction_4_2(x0, Zobs, count);
	xo = x;
	fo = fx;
	dx.resize(N);
	rd.resize(N);
	///starting
	while (1)
	{
		//terminate
		k++;
		if (k > kmax)break;
		//
		Ti = double(k) / double(kmax) * q;
		mu = pow(10, Ti * 100);
		randomVector(rd, 1.0, -1.0);
		Mu_Inv(dx, rd, mu);
		for (int i = 0; i < N; i++)
		{
			dx[i] *= u - l;
		}
		for (int i = N - 1; i < N; i++)
		{
			x1[i] = x[i] + dx[i];
			if (x1[i] > u)x1[i] = u;
			if (x1[i] < l)x1[i] = l;
		}
		fx1 = objectiveFunction_4_2(x1, Zobs, count);
		df = fx1 - fx;
		///
		rand = randomDouble(1.0, 0);
		if (df < 0 || rand < exp(-Ti * df / (abs(fx) + eps) / (TolFun)))
		{
			x = x1;
			fx = fx1;
		}
		if (fx < fo)
		{
			xo = x1;
			fo = fx1;
		}
		///
	}
}
double Walk(double xmod, double xmin, double xmax, double tmp)
{
	std::random_device rd; // 
	std::mt19937 gen(rd()); //  Mersenne Twister 
	std::uniform_real_distribution<double> dis(0.0, 1.0);
	int ntry = 1;
	double arand, ayy, dif, pwr, yy, xmod1;
	while (true)
	{
		arand = dis(gen);
		ayy = 0.0;
		dif = arand - 0.5;
		ayy = sgn(dif);
		pwr = fabs(2 * arand - 1.0);
		yy = ayy * tmp * (pow(1.0 + 1.0 / tmp, pwr) - 1.0);
		xmod1 = xmod + yy * (xmax - xmin);

		if (xmod1 < xmin || xmod1 > xmax) {
			ntry++;
			if (ntry >= 100) {
				break;
			}
		}
		else {
			break;
		}
	}

	if (xmod1 < xmin) xmod1 = xmin;
	if (xmod1 > xmax) xmod1 = xmax;

	return xmod1;
}

double bound(double a, double per, int type)
{
	per = per / 100.;
	double upb = a + abs(a) * per;
	double lwb = a - abs(a) * per;
	if (type == 1)
	{
		return lwb;
	}
	else
	{
		return upb;
	}
}

void _1D_Frequency_part_seeking(int& oneD_frs, int& oneD_fre, int nfre, double* lmbda, double* beta, double _1D_limit, double _2D_limit)
{
	int* oneD_part;
	oneD_part = new int[nfre];
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		int count = 0;
		int jj = 1;
		if (lmbda[ifre] > _1D_limit)oneD_part[ifre] = 0;
		else
		{
			count++;
			while (lmbda[ifre + jj] <= _1D_limit && beta[ifre + jj] <= _2D_limit)
			{
				if (ifre + jj > nfre - 1)break;
				count++;
				jj++;
			}
			oneD_part[ifre] = count;
		}
	}
	int max = oneD_part[0];
	oneD_frs = 0;
	oneD_fre = oneD_part[0] + oneD_frs;
	for (int ifre = 1; ifre < nfre; ifre++)
	{
		if (oneD_part[ifre] > max)
		{
			oneD_frs = ifre;
			oneD_fre = oneD_part[ifre] + oneD_frs;
			max = oneD_part[ifre];
		}
	}
}

void _2D_Frequency_part_seeking(int& twoD_frs, int& twoD_fre, int nfre, double* beta, double* strike, double _2D_limit)
{
	int* twoD_part;
	twoD_part = new int[nfre];
	//find the frequency part
	for (int ifre = 0; ifre < nfre; ifre++)
	{
		double maxIt, minIt;

		vector<double> tmp;
		int count = 0;
		int jj = 1;
		if (abs(beta[ifre] * 180 / PI) > _2D_limit)twoD_part[ifre] = 0;
		else
		{
			count++;
			maxIt = strike[ifre + jj] * 180 / PI;
			minIt = strike[ifre + jj] * 180 / PI;
			while (abs(beta[ifre + jj] * 180 / PI) <= _2D_limit && (abs(strike[ifre + jj] * 180 / PI - maxIt) < 10. && (abs(strike[ifre + jj] * 180 / PI - minIt) < 10.)))
			{
				if (ifre + jj > nfre - 1)break;
				count++;
				jj++;
				tmp.push_back(strike[ifre + jj] * 180 / PI);
				auto aa = std::max_element(tmp.begin(), tmp.end());
				auto bb = std::min_element(tmp.begin(), tmp.end());
				maxIt = static_cast<double>(*aa);
				minIt = static_cast<double>(*bb);
			}
			twoD_part[ifre] = count;
		}
	}
	int max = twoD_part[0];
	twoD_frs = 0;
	twoD_fre = twoD_part[0] + twoD_frs;
	//
	for (int ifre = 1; ifre < nfre; ifre++)
	{
		if (twoD_part[ifre] > max)
		{
			twoD_frs = ifre;
			twoD_fre = twoD_part[ifre] + twoD_frs;
			max = twoD_part[ifre];
		}
	}
}

void Mu_Inv(vector<double>& dx, vector<double> y, double mu)
{
	int N = y.size();
	for (int i = 0; i < N; i++)
	{
		dx[i] = (pow(1 + mu, abs(y[i])) - 1) / mu * sgn(y[i]);
	}
}


void generateGaussianKernel(double* kernel, double sigma, int kernelSize) {
	double sum = 0.0;
	int halfSize = kernelSize / 2;
	double sigma2 = sigma * sigma;
	for (int i = -halfSize; i <= halfSize; ++i) {
		double value = std::exp(-0.5 * (i * i) / sigma2) / (std::sqrt(2 * M_PI) * sigma);
		kernel[i + halfSize] = value;
		sum += value;
	}
	// ��һ��
	for (int i = 0; i < kernelSize; ++i) {
		kernel[i] /= sum;
	}
}


void gaussianSmooth(const double* data, double* smoothedData, int dataSize, double sigma) {
	int kernelSize = std::ceil(6 * sigma); // �˴�Сͨ��ȡ 6 * sigma
	if (kernelSize % 2 == 0) {
		kernelSize += 1; // ȷ���˴�СΪ����
	}
	double* kernel = new double[kernelSize];
	generateGaussianKernel(kernel, sigma, kernelSize);

	int halfSize = kernelSize / 2;
	for (int i = 0; i < dataSize; ++i) {
		double sum = 0.0;
		for (int j = -halfSize; j <= halfSize; ++j) {
			int idx = std::clamp(i + j, 0, dataSize - 1);
			sum += data[idx] * kernel[j + halfSize];
		}
		smoothedData[i] = sum;
	}

	delete[] kernel;
}

