#pragma once
/*
***********************************************************************

COMMON_INCLUDES.h	(COMMON_INCLUDES)

***********************************************************************

Sep 01, 2023
Copyright 2023

Zuwei Huang
hzw1498218560@tongji.edu.cn
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

Luolei Zhang
zhangluolei@hotmail.com
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

version 2.0.0

* ***********************************************************************
*/

#ifndef COMMONHEADERS_H
#define COMMONHEADERS_H

// 
#include <vector>
#include <string>
#include <iostream> // 
#include <fstream>
#include <sstream>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <chrono>
#include <complex>
#include <algorithm>
#include <random>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/IterativeLinearSolvers>
#include <eigen3/Eigen/Cholesky>
#include <eigen3/Eigen/SparseLU>
#include <eigen3/Eigen/LU>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/SparseCore>
#include <eigen3/Eigen/QR>
#include <eigen3/Eigen/SVD>

using namespace Eigen;
using namespace std;

#define PI 3.141592653589793238462643383279502884197169
#define eps 2.2204*pow(10,-16) 

#endif // COMMON_INCLUDES_H#pragma once
