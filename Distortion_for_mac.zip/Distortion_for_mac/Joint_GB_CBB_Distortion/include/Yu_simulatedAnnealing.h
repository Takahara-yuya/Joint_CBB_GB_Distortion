/*
***********************************************************************

Joint_GB_CBB_Distortion.cpp	(Main program)

***********************************************************************

May 21, 2024
Copyright 2024

Zuwei Huang
hzw1498218560@tongji.edu.cn
School of Ocean and Earth Science, Tongji University
Integrated Geophysics Group

Reference:
[1]Bibby, H.M., Caldwell, T.G. and Brown, C. (2005), Determinable and non-determinable parameters of galvanic distortion in magnetotellurics.
	 Geophysical Journal International, 163: 915-930. https://doi.org/10.1111/j.1365-246X.2005.02779.x
[2]Caldwell, T.G., Bibby, H.M. and Brown, C. (2004), The magnetotelluric phase tensor.
	 Geophysical Journal International, 158: 457-469. https://doi.org/10.1111/j.1365-246X.2004.02281.x

version 2.0.0

* ***********************************************************************
*/
#include "CommonHeaders.h"
void multiplyMatrices(double A[2][2], double B[2][2], double result[2][2]);
void inv_multiplyMatrices(double A[2][2], double B[2][2], double result[2][2]);
bool invertMatrix(double matrix[2][2], double inverse[2][2]);
double determinant(double matrix[2][2]);
double sgn(double a);
double calculateMean(const std::vector<double>& data);
double calculateStandardDeviation(const std::vector<double>& data);
void randomVector(vector<double>& rd, double upb, double lwb);
double randomDouble(double upb, double lwb);
void smoothArray(double* arr, int size, int windowSize);
void objectiveFunction_Mul(vector< vector<double> >& x, vector< vector<double> > Zobs, vector< vector<double> > Zvar, double* freq, vector<double>& e
	, double& R);
double objectiveFunction_4_2(vector<double>& x, vector<double> Zobs,int count);
void Yu_simulatedAnnealing(vector< vector<double> >& x, vector< vector<double> > Zobs, vector< vector<double> > Zvar, vector< vector<double> >& x0,
	double* freq, double smooth, vector< vector<double> >& l, vector< vector<double> >& u, vector<double>& obj, vector<double>& obj_s, int fres, int free);
void SimulatedAnnealing_4_2(vector<double>& xo, vector<double> Zobs, vector<double>& x0
	, double l, double u,int count);
double Walk(double xmod, double xmin, double xmax, double tmp);
double bound(double a, double per, int type);
void _1D_Frequency_part_seeking(int& oneD_frs, int& oneD_fre, int nfre, double* lmbda, double* beta, double _1D_limit, double _2D_limit);
void _2D_Frequency_part_seeking(int& twoD_frs, int& twoD_fre, int nfre, double* beta, double* strike, double _2D_limit);
void Mu_Inv(vector<double>& dx, vector<double> y, double mu);
void gaussianSmooth(const double* data, double* smoothedData, int dataSize, double sigma);
void generateGaussianKernel(double* kernel, double sigma, int kernelSize);