######

plot_input=Surveyline_Curve_plot/inputfile
plot_file=Surveyline_Curve_plot/file
plot_result=Surveyline_Curve_plot/result
plot_catalogue=Surveyline_Curve_plot/catalogue
result=Joint_GB_CBB_Distortion/result
Static_shift_input=Static_shift
Strike_ambiguity_input=Strike_ambiguity/inputfile
Strike_ambiguity_output=Strike_ambiguity/outputfile

##Disotrtion######

cd Joint_GB_CBB_Distortion
make clean	
sudo make
#./Impedance_Decompsition

##############
cd ..

rm -rf $plot_file
mkdir $plot_file
rm -rf $plot_input
mkdir $plot_input
rm -rf $plot_result
mkdir $plot_result
rm -rf $plot_catalogue
mkdir $plot_catalogue

#cp $result/2D_distortion.dat $plot_input/2D_distortion.dat
cp $result/2D_distortion.dat $Strike_ambiguity_input/2D_distortion.dat
cp $result/Original_data.dat $plot_input/Original_data.dat
#cp $result/Phase_Tensor_Analysis.dat $plot_input/Phase_Tensor_Analysis.dat
cp $result/Phase_Tensor_Analysis.dat $Strike_ambiguity_input/Phase_Tensor_Analysis.dat
cp $result/debug.dat $plot_input/debug.dat
cp $result/debug.dat $Static_shift_input/debug.dat
cp $result/simulatedAnnealing.dat $plot_input/simulatedAnnealing.dat

####strike ambiguity####

cd Strike_ambiguity
g++ Strike_ambiguity.cpp
./a.out
rm a.out
sudo bash Strike_statistic_plot/strike_statistic.sh

cd ..

cp $Strike_ambiguity_output/2D_distortion.dat $Static_shift_input/2D_distortion.dat
cp $Strike_ambiguity_output/Phase_Tensor_Analysis.dat $plot_input/Phase_Tensor_Analysis.dat
cp $Strike_ambiguity_output/Static_100_1s_strike.dat $plot_file/Static_100_1s_strike.dat

####static shift####

cd Static_shift
gfortran Line_Static_Shift.for
./a.out

cd ..
cp $Static_shift_input/tem-in-mode.dat $plot_input/2D_distortion.dat

######2D plot########

cd Surveyline_Curve_plot
g++  Surveyline_data_2D.cpp
./a.out
rm a.out

sudo bash plot2D.sh

######1D plot######

g++  Surveyline_data_block.cpp
./a.out
rm a.out

sudo bash plot.sh

##############
