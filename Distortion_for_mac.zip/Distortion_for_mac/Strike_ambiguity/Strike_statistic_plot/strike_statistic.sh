#!/usr/bin/env bash

gmt histogram Static_100_1s_strike.dat -JX15c/9c -R-90/90/0/200 -Bxaf+l"Strike" -Byaf+l"Counts" -BWSen -W1p -Gblue -T5 -i2 -png hist

#aa中三列： site   freq  strike   
#长度与JX中的长度成比例！
