#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;
#define PI 3.141592653589793238462643383279502884197169
int main()
{
	bool exc=true;
	double tmp;
	string tmp2;
	double* RhoTE, * RhoTM, * PhaTE, * PhaTM;
	double* errRhoTE, * errRhoTM, * errPhaTE, * errPhaTM;
	double* site, * freq;
	double* beta, * strike, * lmbda;
	string* pmin, * pmax;
	int nfre, nsite;
	string filename = "inputfile/2D_distortion.dat";
	ifstream fin(filename);
	if (!fin)
	{
		cerr << "2D_distortion.dat open failed!" << endl;
		exit(1);
	}
	string filename2 = "inputfile/Phase_Tensor_Analysis.dat";
	ifstream fin2(filename2);
	if (!fin2)
	{
		cerr << "Phase_Tensor_Analysis.dat open failed!" << endl;
		exit(1);
	}
	fin >> nsite >> nfre;
	string data;
	getline(fin2, data);
	ofstream fout3("outputfile/2D_distortion.dat");
	ofstream fout4("outputfile/Phase_Tensor_Analysis.dat");
	ofstream fout5("Strike_statistic_plot/Static_100_1s_strike.dat");
	ofstream fout6("outputfile/Static_100_1s_strike.dat");
	fout3 << nsite << " " << nfre << endl;
	fout4 << data << endl;

	freq = new double[nfre];
	RhoTE = new double[nfre]; RhoTM = new double[nfre]; PhaTE = new double[nfre]; PhaTM = new double[nfre];
	errRhoTE = new double[nfre]; errRhoTM = new double[nfre]; errPhaTE = new double[nfre]; errPhaTM = new double[nfre];
	site = new double[nsite]; beta = new double[nfre]; strike = new double[nfre]; lmbda = new double[nfre]; pmin = new string[nfre]; pmax = new string[nfre];
	double* ave = new double[nsite];
	int count;
	///
	for (int isite = 0; isite < nsite; isite++)
	{
		ave[isite] = 0;
		count = 0;
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			fin >> site[isite] >> freq[ifre] >> RhoTE[ifre] >> PhaTE[ifre] >> RhoTM[ifre] >> PhaTM[ifre]
				>> errRhoTE[ifre] >> errRhoTM[ifre] >> errPhaTE[ifre] >> errPhaTM[ifre];
			fin2 >> site[isite] >> freq[ifre] >> beta[ifre] >> strike[ifre] >> lmbda[ifre] >> pmin[ifre] >> pmax[ifre];
		}
		for (int ifre = 0; ifre < nfre; ifre++)
		{
			if (freq[ifre] <= 0 && freq[ifre] >= -2)
			{
				count++;
				ave[isite] += strike[ifre];
			}
		}
		ave[isite] /= count;
		//
		if (ave[isite] >= 70 && exc)
		{
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				strike[ifre] = strike[ifre] - 90;
				fout4 << site[isite] << " " << freq[ifre] << " " << beta[ifre] << " " << strike[ifre] << " " << lmbda[ifre] << " " << pmin[ifre] << " " << pmax[ifre] << endl;
				fout3 << site[isite] << " " << freq[ifre] << " " << RhoTM[ifre] << " " << PhaTM[ifre] << " " << RhoTE[ifre] << " " << PhaTE[ifre]
					<< " " << errRhoTM[ifre] << " " << errRhoTE[ifre] << " " << errPhaTM[ifre] << " " << errPhaTE[ifre] << endl;
				if (freq[ifre] <= 0 && freq[ifre] >= -2)
				{
					fout5 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
					fout6 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
				}
			}
		}
		else if (ave[isite] <= -20 && exc)
		{
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				strike[ifre] = strike[ifre] + 90;
				fout4 << site[isite] << " " << freq[ifre] << " " << beta[ifre] << " " << strike[ifre] << " " << lmbda[ifre] << " " << pmin[ifre] << " " << pmax[ifre] << endl;
				fout3 << site[isite] << " " << freq[ifre] << " " << RhoTM[ifre] << " " << PhaTM[ifre] << " " << RhoTE[ifre] << " " << PhaTE[ifre]
					<< " " << errRhoTM[ifre] << " " << errRhoTE[ifre] << " " << errPhaTM[ifre] << " " << errPhaTE[ifre] << endl;
				if (freq[ifre] <= 0 && freq[ifre] >= -2)
				{
					fout5 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
					fout6 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
				}
			}
		}
		else
		{
			for (int ifre = 0; ifre < nfre; ifre++)
			{
				fout4 << site[isite] << " " << freq[ifre] << " " << beta[ifre] << " " << strike[ifre] << " " << lmbda[ifre] << " " << pmin[ifre] << " " << pmax[ifre] << endl;
				fout3 << site[isite] << " " << freq[ifre] << " " << RhoTE[ifre] << " " << PhaTE[ifre] << " " << RhoTM[ifre] << " " << PhaTM[ifre]
					<< " " << errRhoTE[ifre] << " " << errRhoTM[ifre] << " " << errPhaTE[ifre] << " " << errPhaTM[ifre] << endl;
				if (freq[ifre] <= 0 && freq[ifre] >= -2)
				{
					fout5 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
					fout6 << site[isite] << " " << freq[ifre] << " " << strike[ifre] << endl;
				}
			}
		}
	}
	////
}